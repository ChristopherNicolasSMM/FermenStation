#pragma once
#include "storage.h"

void localControlLogic(float tFer, float tAmb, float tDeg);
void setRelayState(int pin, bool state);
