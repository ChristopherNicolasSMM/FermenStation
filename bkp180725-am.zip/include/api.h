#pragma once
#include "supabase.h"

void handleGetConfig(AsyncWebServerRequest *request);
void handleGetLogs(AsyncWebServerRequest *request);
void handleGetCurrentReadings(AsyncWebServerRequest *request);
void handleSaveConfig(AsyncWebServerRequest *request);
void handleResetConfig(AsyncWebServerRequest *request);
void handleRestartDevice(AsyncWebServerRequest *request);
void handleNotFound(AsyncWebServerRequest *request);

void setupAPIEndpoints();
