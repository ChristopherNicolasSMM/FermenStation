#pragma once
#include "controle.h"

void initSensores();
float readDSTemperature(DeviceAddress addr, DallasTemperature &sensor);
void debugAllSensors();
