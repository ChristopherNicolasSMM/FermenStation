#pragma once
#include "config.h"

void addLog(String message);
extern String logs[MAX_LOGS];
extern int currentLogIndex;
extern bool logBufferFull;
