#pragma once
#include "sensores.h"

String callSupabaseRpc(const String &rpcName, const String &payload);
bool validateDeviceOnSupabase();
bool getActiveProcessOnSupabase();
void controlFermenstationOnSupabase(const float &tempFermentador, const float &tempAmbiente, const float &tempDegelo, const float &gravidade = -1.0);
