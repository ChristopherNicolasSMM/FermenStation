#pragma once
#include "api.h"

void startWebServer();
