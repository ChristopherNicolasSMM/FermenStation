#pragma once

#include <WiFi.h>
#include <WiFiAP.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <Preferences.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <AsyncTCP.h>
#include <ESPAsyncWebServer.h>

// --- DEFINIÇÕES GLOBAIS E CONSTANTES ---
#define DEBUG_MODE true
#define MAX_LOGS 60
#define WIFI_TIMEOUT 30000 // 30 segundos

IPAddress apIP(192, 168, 0, 1);
IPAddress apGateway(192, 168, 0, 1);
IPAddress apSubnet(255, 255, 255, 0);

// --- CONFIGURAÇÕES DO SUPABASE ---
const char *SUPABASE_URL = "https://ftycjulkovsffzdxpcwf.supabase.co/rest/v1";
const char *SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZ0eWNqdWxrb3ZzZmZ6ZHhwY3dmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTE0NTU4NDEsImV4cCI6MjA2NzAzMTg0MX0.vreBc6iAqfgampJMrbFx_6AUO6PtjuOMjJVGCvuyu-Q";

// --- DEFINIÇÕES DOS PINOS ---
// --- DEFINIÇÕES DOS PINOS ---
const int PINO_FERMENTADOR = 16; // GPIO16 para sensor do fermentador
const int PINO_AMBIENTE = 17;    // GPIO17 para sensor ambiente
const int PINO_DEGELO = 18;      // GPIO18 para sensor de degelo

// Remove estas linhas (não serão usadas):
// const int ONE_WIRE_BUS = 4;
// OneWire oneWire(ONE_WIRE_BUS);
// DallasTemperature sensors(&oneWire);

// Barramentos OneWire independentes para cada sensor:
OneWire oneWireFermentador(PINO_FERMENTADOR);
OneWire oneWireAmbiente(PINO_AMBIENTE);
OneWire oneWireDegelo(PINO_DEGELO);

// Instâncias DallasTemperature para cada sensor:
DallasTemperature sensorFermentador(&oneWireFermentador);
DallasTemperature sensorAmbiente(&oneWireAmbiente);
DallasTemperature sensorDegelo(&oneWireDegelo);

// Endereços dos sensores (mantidos):
DeviceAddress tempFermentadorAddress;
DeviceAddress tempAmbienteAddress;
DeviceAddress tempDegeloAddress;

const int RELAY_PIN_AQUECIMENTO = 27;
const int RELAY_PIN_RESFRIAMENTO = 26;
const int RELAY_PIN_DEGELO = 25;
const int RESET_BUTTON_PIN = 0;
const unsigned long RESET_BUTTON_HOLD_TIME_MS = 5000;

// --- VARIÁVEIS GLOBAIS ---
Preferences preferences;
AsyncWebServer server(80);

String savedSsid = "";
String savedPassword = "";
String savedDeviceId = "";
String savedProcessId = "";

String savedDegeloModo = "desativado";
String savedDegeloTempo = "00:00";
float savedDegeloTemperatura = 5.0;
float savedTemperaturaMinSeguranca = 0.0;
float savedTemperaturaMaxSeguranca = 35.0;
float savedTemperaturaAlvoLocal = 20.0;
float savedVariacaoTemperaturaLocal = 0.5;

bool wifiConnected = false;
bool apModeActive = false;
bool processFound = false;
int wifiErrorCount = 0;
const int MAX_WIFI_ERRORS = 5;

bool currentRelayAquecimentoState = false;
bool currentRelayResfriamentoState = false;
bool currentRelayDegeloState = false;

String logs[MAX_LOGS];
int currentLogIndex = 0;
bool logBufferFull = false;

unsigned long lastSensorReadTime = 0;
const unsigned long SENSOR_READ_INTERVAL_MS = 30000;
const unsigned long OFFLINE_RETRY_INTERVAL_MS = 60000;
unsigned long lastOfflineRetryTime = 0;
unsigned long buttonPressStartTime = 0;