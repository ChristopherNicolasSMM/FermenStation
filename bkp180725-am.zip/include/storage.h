#pragma once
#include "log.h"

void saveConfigurations();
void loadConfigurations();
void clearConfigurations();
