#pragma once
#include "server.h"

void connectToWiFi();
void checkWiFiConnection();
void startAPMode();
String getWiFiStatusString(int status);
void scanNetworks();
