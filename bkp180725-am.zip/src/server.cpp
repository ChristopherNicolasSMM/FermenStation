#include "server.h"

void startWebServer() {
    server.begin();
}
