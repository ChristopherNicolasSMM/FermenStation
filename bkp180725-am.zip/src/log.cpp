#include "log.h"
/*
String logs[MAX_LOGS];
int currentLogIndex = 0;
bool logBufferFull = false;

void addLog(String message) {
    logs[currentLogIndex] = message;
    currentLogIndex = (currentLogIndex + 1) % MAX_LOGS;
    if (currentLogIndex == 0) logBufferFull = true;

    if (DEBUG_MODE) Serial.println(message);
}*/


void addLog(String message)
{
    logs[currentLogIndex] = message;
    currentLogIndex = (currentLogIndex + 1) % MAX_LOGS;
    if (currentLogIndex == 0)
        logBufferFull = true;

    if (DEBUG_MODE)
    {
        Serial.println(message);
    }
}
