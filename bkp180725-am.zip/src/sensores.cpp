#include "sensores.h"

void initSensores() {}

float readDSTemperature(DeviceAddress sensorAddress, DallasTemperature &sensorInstance)
{
    sensorInstance.requestTemperatures();
    float tempC = sensorInstance.getTempC(sensorAddress);
    if (tempC == DEVICE_DISCONNECTED_C)
    {
        addLog("Erro ao ler sensor de temperatura.");
        return -127.0;
    }
    return tempC;
}

void debugAllSensors()
{
    addLog("[DEBUG] Temperaturas:");
    addLog("Fermentador: " + String(readDSTemperature(tempFermentadorAddress, sensorFermentador)) + "°C");
    addLog("Ambiente: " + String(readDSTemperature(tempAmbienteAddress, sensorAmbiente)) + "°C");
    addLog("Degelo: " + String(readDSTemperature(tempDegeloAddress, sensorDegelo)) + "°C");
}

